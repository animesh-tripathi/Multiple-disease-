# Multiple-disease-pridiction-system
The proposed system is a comprehensive disease prediction project that utilizes machine learning algorithms, including Support Vector Machine (SVM), Logistic Regression, TensorFlow with Keras, to predict multiple diseases such as diabetes, heart disease, kidney disease and Parkinson's disease
